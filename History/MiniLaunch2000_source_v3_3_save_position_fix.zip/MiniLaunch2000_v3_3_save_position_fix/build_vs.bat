@echo off
chcp 65001 >nul
rem 请在 “x64 Native Tools Command Prompt for VS” 里运行
cl /EHsc /DUNICODE /D_UNICODE /O2 MiniLaunch2000.cpp /link /SUBSYSTEM:WINDOWS comctl32.lib shell32.lib shlwapi.lib comdlg32.lib /OUT:MiniLaunch2000.exe
