@echo off
chcp 65001 >nul
where x86_64-w64-mingw32-g++ >nul 2>nul
if %errorlevel%==0 (
  x86_64-w64-mingw32-g++ -municode -O2 -s -static -mwindows MiniLaunch2000.cpp -o MiniLaunch2000.exe -lcomctl32 -lshell32 -lshlwapi -lcomdlg32
  goto :eof
)
g++ -municode -O2 -s -static -mwindows MiniLaunch2000.cpp -o MiniLaunch2000.exe -lcomctl32 -lshell32 -lshlwapi -lcomdlg32
