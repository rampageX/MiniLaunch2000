#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0601
#endif
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <shellapi.h>
#include <shlwapi.h>
#include <stdio.h>

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "shlwapi.lib")

#define APP_NAME L"MiniLaunch2000"
#define MAX_ITEMS 512
#define WM_TRAY (WM_APP + 1)
#define ID_FIRST_ITEM 1000
#define ID_MENU_RELOAD 40001
#define ID_MENU_OPENINI 40002
#define ID_MENU_ADD 40003
#define ID_MENU_EXIT 40004
#define ID_MENU_ONTOP 40005
#define ID_MENU_EDITINI 40006

typedef struct ITEM {
    WCHAR name[128];
    WCHAR path[MAX_PATH];
    WCHAR args[512];
    WCHAR workdir[MAX_PATH];
    WCHAR iconPath[MAX_PATH];
    int iconIndex;
    HICON hIcon;
    HWND hBtn;
} ITEM;

static HINSTANCE g_hInst;
static HWND g_hwnd;
static ITEM g_items[MAX_ITEMS];
static int g_count = 0;
static int g_iconSize = 16;
static int g_cellW = 24;
static int g_cellH = 24;
static int g_maxColumns = 16;
static int g_margin = 4;
static BOOL g_stayOnTop = TRUE;
static BOOL g_showCaption = FALSE;
static int g_startX = CW_USEDEFAULT;
static int g_startY = CW_USEDEFAULT;
static BOOL g_haveSavedPos = FALSE;
static WCHAR g_ini[MAX_PATH];
static HFONT g_font;
static HWND g_tooltip;

static void GetExeDirFile(const WCHAR* file, WCHAR* out, DWORD cch) {
    GetModuleFileNameW(NULL, out, cch);
    PathRemoveFileSpecW(out);
    PathAppendW(out, file);
}

static void Trim(WCHAR* s) {
    size_t n = wcslen(s);
    while (n && (s[n-1] == L' ' || s[n-1] == L'\t' || s[n-1] == L'\r' || s[n-1] == L'\n')) s[--n] = 0;
}


static BOOL ReadIniIntValue(const WCHAR* section, const WCHAR* key, int* out) {
    WCHAR buf[64] = L"";
    GetPrivateProfileStringW(section, key, L"", buf, 64, g_ini);
    Trim(buf);
    if (!buf[0]) return FALSE;
    *out = _wtoi(buf);
    return TRUE;
}

static void LoadStartupPosition(void) {
    int x = 0, y = 0;
    if (!ReadIniIntValue(L"Settings", L"WindowX", &x) || !ReadIniIntValue(L"Settings", L"WindowY", &y)) {
        g_haveSavedPos = FALSE;
        g_startX = CW_USEDEFAULT;
        g_startY = CW_USEDEFAULT;
        return;
    }

    // Keep the restored position inside the virtual desktop, useful after changing monitors.
    int vx = GetSystemMetrics(SM_XVIRTUALSCREEN);
    int vy = GetSystemMetrics(SM_YVIRTUALSCREEN);
    int vw = GetSystemMetrics(SM_CXVIRTUALSCREEN);
    int vh = GetSystemMetrics(SM_CYVIRTUALSCREEN);
    if (x < vx - 200 || x > vx + vw - 8 || y < vy - 200 || y > vy + vh - 8) {
        g_haveSavedPos = FALSE;
        g_startX = CW_USEDEFAULT;
        g_startY = CW_USEDEFAULT;
        return;
    }
    g_haveSavedPos = TRUE;
    g_startX = x;
    g_startY = y;
}

static void SaveWindowPlacement(void) {
    if (!g_hwnd || !IsWindow(g_hwnd)) return;
    RECT r;
    if (!GetWindowRect(g_hwnd, &r)) return;
    WCHAR buf[32];
    wsprintfW(buf, L"%d", r.left);  WritePrivateProfileStringW(L"Settings", L"WindowX", buf, g_ini);
    wsprintfW(buf, L"%d", r.top);   WritePrivateProfileStringW(L"Settings", L"WindowY", buf, g_ini);
    wsprintfW(buf, L"%d", r.right - r.left);  WritePrivateProfileStringW(L"Settings", L"WindowW", buf, g_ini);
    wsprintfW(buf, L"%d", r.bottom - r.top);  WritePrivateProfileStringW(L"Settings", L"WindowH", buf, g_ini);
}

static void DestroyIcons(void) {
    for (int i=0;i<g_count;i++) {
        if (g_items[i].hIcon) { DestroyIcon(g_items[i].hIcon); g_items[i].hIcon = NULL; }
    }
}

static HICON LoadItemIcon(ITEM* it) {
    WCHAR src[MAX_PATH];
    lstrcpynW(src, it->iconPath[0] ? it->iconPath : it->path, MAX_PATH);
    if (!src[0]) return NULL;
    HICON big = NULL, small = NULL;
    UINT got = ExtractIconExW(src, it->iconIndex, &big, &small, 1);
    HICON h = NULL;
    if (got) {
        if (g_iconSize <= 16 && small) h = small;
        else if (big) h = big;
        else h = small;
        if (h == small && big) DestroyIcon(big);
        if (h == big && small) DestroyIcon(small);
    }
    if (!h) {
        SHFILEINFOW sfi = {0};
        DWORD flags = SHGFI_ICON | (g_iconSize <= 16 ? SHGFI_SMALLICON : SHGFI_LARGEICON);
        if (SHGetFileInfoW(src, 0, &sfi, sizeof(sfi), flags)) h = sfi.hIcon;
    }
    return h;
}

static void WriteDefaultIni(void) {
    if (PathFileExistsW(g_ini)) return;
    WCHAR notepad[MAX_PATH] = L"notepad.exe";
    WCHAR calc[MAX_PATH] = L"calc.exe";
    FILE* f = _wfopen(g_ini, L"wb");
    if (!f) return;
    const unsigned char bom[2] = {0xFF,0xFE};
    fwrite(bom,1,2,f);
    fwprintf(f, L"[Settings]\r\nIconSize=16\r\nMaxColumns=16\r\n; Columns 仍兼容旧配置；建议改用 MaxColumns。\r\nCellWidth=24\r\nCellHeight=24\r\nMargin=4\r\nStayOnTop=1\r\nShowCaption=0\r\n; WindowX/WindowY 会在退出时自动保存。\r\nWindowX=\r\nWindowY=\r\nWindowW=\r\nWindowH=\r\n\r\n");
    fwprintf(f, L"; Path 可填 exe、bat、cmd、lnk、文件夹或网址。\r\n; Args 是启动参数，WorkDir 是工作目录，Icon 可单独指定图标文件。\r\n\r\n");
    fwprintf(f, L"[Item1]\r\nName=Notepad\r\nPath=%s\r\nArgs=\r\nWorkDir=\r\nIcon=\r\nIconIndex=0\r\n\r\n", notepad);
    fwprintf(f, L"[Item2]\r\nName=Calculator\r\nPath=%s\r\nArgs=\r\nWorkDir=\r\nIcon=\r\nIconIndex=0\r\n", calc);
    fclose(f);
}

static void LoadConfig(void) {
    DestroyIcons();
    g_count = 0;
    g_iconSize = GetPrivateProfileIntW(L"Settings", L"IconSize", 16, g_ini);
    if (g_iconSize < 12) g_iconSize = 12;
    if (g_iconSize > 64) g_iconSize = 64;
    // Auto-width mode: window width follows icon count, and wraps after MaxColumns.
    // For compatibility, old INI key "Columns" is still accepted when MaxColumns is absent.
    g_maxColumns = GetPrivateProfileIntW(L"Settings", L"MaxColumns", -1, g_ini);
    if (g_maxColumns < 0) g_maxColumns = GetPrivateProfileIntW(L"Settings", L"Columns", 16, g_ini);
    if (g_maxColumns < 1) g_maxColumns = 1;
    if (g_maxColumns > 64) g_maxColumns = 64;
    g_cellW = GetPrivateProfileIntW(L"Settings", L"CellWidth", g_iconSize + 8, g_ini);
    g_cellH = GetPrivateProfileIntW(L"Settings", L"CellHeight", g_iconSize + 8, g_ini);
    g_margin = GetPrivateProfileIntW(L"Settings", L"Margin", 4, g_ini);
    g_stayOnTop = GetPrivateProfileIntW(L"Settings", L"StayOnTop", 1, g_ini) ? TRUE : FALSE;
    g_showCaption = GetPrivateProfileIntW(L"Settings", L"ShowCaption", 0, g_ini) ? TRUE : FALSE;
    for (int i=1; i<=MAX_ITEMS; i++) {
        WCHAR sec[32]; wsprintfW(sec, L"Item%d", i);
        WCHAR path[MAX_PATH] = L"";
        GetPrivateProfileStringW(sec, L"Path", L"", path, MAX_PATH, g_ini);
        Trim(path);
        if (!path[0]) continue;
        ITEM* it = &g_items[g_count];
        ZeroMemory(it, sizeof(ITEM));
        GetPrivateProfileStringW(sec, L"Name", path, it->name, 128, g_ini);
        lstrcpynW(it->path, path, MAX_PATH);
        GetPrivateProfileStringW(sec, L"Args", L"", it->args, 512, g_ini);
        GetPrivateProfileStringW(sec, L"WorkDir", L"", it->workdir, MAX_PATH, g_ini);
        GetPrivateProfileStringW(sec, L"Icon", L"", it->iconPath, MAX_PATH, g_ini);
        it->iconIndex = GetPrivateProfileIntW(sec, L"IconIndex", 0, g_ini);
        it->hIcon = LoadItemIcon(it);
        g_count++;
        if (g_count >= MAX_ITEMS) break;
    }
}

static void AddTooltip(HWND hBtn, const WCHAR* text) {
    if (!g_tooltip) return;
    TOOLINFOW ti = {0};
    ti.cbSize = sizeof(ti);
    ti.uFlags = TTF_IDISHWND | TTF_SUBCLASS;
    ti.hwnd = g_hwnd;
    ti.uId = (UINT_PTR)hBtn;
    ti.lpszText = (LPWSTR)text;
    SendMessageW(g_tooltip, TTM_ADDTOOLW, 0, (LPARAM)&ti);
}

static void ClearButtons(void) {
    for (int i=0;i<MAX_ITEMS;i++) {
        if (g_items[i].hBtn) { DestroyWindow(g_items[i].hBtn); g_items[i].hBtn = NULL; }
    }
}

static void LayoutButtons(void) {
    ClearButtons();
    if (!g_tooltip) {
        g_tooltip = CreateWindowExW(WS_EX_TOPMOST, TOOLTIPS_CLASSW, NULL, WS_POPUP | TTS_ALWAYSTIP | TTS_NOPREFIX,
            CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, g_hwnd, NULL, g_hInst, NULL);
    }
    // Actual columns are automatic:
    // 0 items -> 1 column placeholder, 1..MaxColumns -> exactly item count, >MaxColumns -> wrap.
    int actualColumns = g_count;
    if (actualColumns < 1) actualColumns = 1;
    if (actualColumns > g_maxColumns) actualColumns = g_maxColumns;
    int rows = (g_count + actualColumns - 1) / actualColumns;
    if (rows < 1) rows = 1;
    int w = g_margin*2 + actualColumns*g_cellW;
    int h = g_margin*2 + rows*g_cellH;
    DWORD style = WS_POPUP | WS_CLIPCHILDREN;
    if (g_showCaption) style |= WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX;
    SetWindowLongPtrW(g_hwnd, GWL_STYLE, style);
    SetWindowPos(g_hwnd, g_stayOnTop ? HWND_TOPMOST : HWND_NOTOPMOST, 0,0,w,h,
        SWP_NOMOVE | SWP_FRAMECHANGED | SWP_SHOWWINDOW);
    RECT wr = {0,0,w,h}; AdjustWindowRectEx(&wr, style, FALSE, WS_EX_TOOLWINDOW);
    SetWindowPos(g_hwnd, NULL, 0,0, wr.right-wr.left, wr.bottom-wr.top, SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);

    for (int i=0;i<g_count;i++) {
        int col = i % actualColumns;
        int row = i / actualColumns;
        int x = g_margin + col*g_cellW;
        int y = g_margin + row*g_cellH;
        HWND b = CreateWindowExW(0, L"BUTTON", L"", WS_CHILD|WS_VISIBLE|BS_ICON|BS_FLAT,
            x, y, g_cellW, g_cellH, g_hwnd, (HMENU)(INT_PTR)(ID_FIRST_ITEM+i), g_hInst, NULL);
        g_items[i].hBtn = b;
        if (g_items[i].hIcon) SendMessageW(b, BM_SETIMAGE, IMAGE_ICON, (LPARAM)g_items[i].hIcon);
        AddTooltip(b, g_items[i].name[0] ? g_items[i].name : g_items[i].path);
    }
    InvalidateRect(g_hwnd, NULL, TRUE);
}

static void RunItem(int idx) {
    if (idx < 0 || idx >= g_count) return;
    ITEM* it = &g_items[idx];
    HINSTANCE r = ShellExecuteW(g_hwnd, L"open", it->path, it->args[0] ? it->args : NULL, it->workdir[0] ? it->workdir : NULL, SW_SHOWNORMAL);
    if ((INT_PTR)r <= 32) MessageBoxW(g_hwnd, L"启动失败。请检查 INI 中的 Path/Args/WorkDir。", APP_NAME, MB_ICONERROR);
}

static void ReloadAll(void) { LoadConfig(); LayoutButtons(); }

static void OpenIni(BOOL edit) {
    ShellExecuteW(g_hwnd, edit ? L"edit" : L"open", g_ini, NULL, NULL, SW_SHOWNORMAL);
}

static void AppendItemFromDialog(void) {
    WCHAR file[MAX_PATH] = L"";
    OPENFILENAMEW ofn = {0};
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = g_hwnd;
    ofn.lpstrFile = file;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrFilter = L"Programs and shortcuts\0*.exe;*.bat;*.cmd;*.lnk;*.msc;*.cpl\0All files\0*.*\0";
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;
    if (!GetOpenFileNameW(&ofn)) return;
    int n = g_count + 1;
    WCHAR sec[32]; wsprintfW(sec, L"Item%d", n);
    WCHAR title[128]; lstrcpynW(title, PathFindFileNameW(file), 128); PathRemoveExtensionW(title);
    WritePrivateProfileStringW(sec, L"Name", title, g_ini);
    WritePrivateProfileStringW(sec, L"Path", file, g_ini);
    WritePrivateProfileStringW(sec, L"Args", L"", g_ini);
    WritePrivateProfileStringW(sec, L"WorkDir", L"", g_ini);
    WritePrivateProfileStringW(sec, L"Icon", L"", g_ini);
    WritePrivateProfileStringW(sec, L"IconIndex", L"0", g_ini);
    ReloadAll();
}

static void ShowContextMenu(POINT pt) {
    HMENU m = CreatePopupMenu();
    AppendMenuW(m, MF_STRING, ID_MENU_ADD, L"添加程序...");
    AppendMenuW(m, MF_STRING, ID_MENU_OPENINI, L"打开配置 INI");
    AppendMenuW(m, MF_STRING, ID_MENU_EDITINI, L"编辑配置 INI");
    AppendMenuW(m, MF_STRING, ID_MENU_RELOAD, L"重新加载");
    AppendMenuW(m, MF_SEPARATOR, 0, NULL);
    AppendMenuW(m, MF_STRING | (g_stayOnTop ? MF_CHECKED : 0), ID_MENU_ONTOP, L"窗口置顶");
    AppendMenuW(m, MF_SEPARATOR, 0, NULL);
    AppendMenuW(m, MF_STRING, ID_MENU_EXIT, L"退出");
    SetForegroundWindow(g_hwnd);
    int id = TrackPopupMenu(m, TPM_RETURNCMD | TPM_RIGHTBUTTON, pt.x, pt.y, 0, g_hwnd, NULL);
    DestroyMenu(m);
    switch(id) {
        case ID_MENU_ADD: AppendItemFromDialog(); break;
        case ID_MENU_OPENINI: OpenIni(FALSE); break;
        case ID_MENU_EDITINI: OpenIni(TRUE); break;
        case ID_MENU_RELOAD: ReloadAll(); break;
        case ID_MENU_ONTOP:
            g_stayOnTop = !g_stayOnTop;
            WritePrivateProfileStringW(L"Settings", L"StayOnTop", g_stayOnTop ? L"1" : L"0", g_ini);
            LayoutButtons(); break;
        case ID_MENU_EXIT: SaveWindowPlacement(); DestroyWindow(g_hwnd); break;
    }
}

static void AddTray(void) {
    NOTIFYICONDATAW nid = {0};
    nid.cbSize = sizeof(nid);
    nid.hWnd = g_hwnd;
    nid.uID = 1;
    nid.uFlags = NIF_MESSAGE | NIF_TIP | NIF_ICON;
    nid.uCallbackMessage = WM_TRAY;
    nid.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    lstrcpynW(nid.szTip, APP_NAME, ARRAYSIZE(nid.szTip));
    Shell_NotifyIconW(NIM_ADD, &nid);
}
static void DelTray(void) {
    NOTIFYICONDATAW nid = {0}; nid.cbSize = sizeof(nid); nid.hWnd = g_hwnd; nid.uID = 1; Shell_NotifyIconW(NIM_DELETE, &nid);
}

static LRESULT CALLBACK WndProc(HWND h, UINT msg, WPARAM w, LPARAM l) {
    switch(msg) {
    case WM_CREATE:
        // CreateWindowExW sends WM_CREATE before it returns, so the global g_hwnd
        // has not been assigned yet in wWinMain.  Use the real window handle now,
        // otherwise the first LayoutButtons() creates no visible child buttons.
        g_hwnd = h;
        AddTray();
        ReloadAll();
        return 0;
    case WM_COMMAND:
        if (LOWORD(w) >= ID_FIRST_ITEM && LOWORD(w) < ID_FIRST_ITEM + MAX_ITEMS) {
            RunItem(LOWORD(w) - ID_FIRST_ITEM);
            return 0;
        }
        break;
    case WM_CONTEXTMENU: {
        POINT pt;
        if ((HWND)w && (HWND)w != h) {
            pt.x = GET_X_LPARAM(l); pt.y = GET_Y_LPARAM(l);
            if (pt.x == -1 && pt.y == -1) { RECT r; GetWindowRect((HWND)w, &r); pt.x = r.left; pt.y = r.bottom; }
        } else { pt.x = GET_X_LPARAM(l); pt.y = GET_Y_LPARAM(l); }
        ShowContextMenu(pt); return 0;
    }
    case WM_LBUTTONDOWN:
        if (!g_showCaption) SendMessageW(h, WM_NCLBUTTONDOWN, HTCAPTION, 0);
        return 0;
    case WM_TRAY:
        if (l == WM_LBUTTONDBLCLK) ShowWindow(h, IsWindowVisible(h) ? SW_HIDE : SW_SHOW);
        if (l == WM_RBUTTONUP) { POINT pt; GetCursorPos(&pt); ShowContextMenu(pt); }
        return 0;
    case WM_CLOSE:
        SaveWindowPlacement();
        DestroyWindow(h);
        return 0;
    case WM_DESTROY:
        SaveWindowPlacement();
        DelTray(); DestroyIcons(); PostQuitMessage(0); return 0;
    }
    return DefWindowProcW(h,msg,w,l);
}

int APIENTRY wWinMain(HINSTANCE hInst, HINSTANCE, LPWSTR, int nCmdShow) {
    g_hInst = hInst;
    INITCOMMONCONTROLSEX icc = { sizeof(icc), ICC_WIN95_CLASSES | ICC_BAR_CLASSES }; InitCommonControlsEx(&icc);
    GetExeDirFile(L"MiniLaunch2000.ini", g_ini, MAX_PATH);
    WriteDefaultIni();
    LoadStartupPosition();
    WNDCLASSEXW wc = {0};
    wc.cbSize = sizeof(wc);
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInst;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE+1);
    wc.lpszClassName = APP_NAME;
    RegisterClassExW(&wc);
    g_hwnd = CreateWindowExW(WS_EX_TOOLWINDOW, APP_NAME, APP_NAME, WS_POPUP,
        g_startX, g_startY, 400, 80, NULL, NULL, hInst, NULL);
    ShowWindow(g_hwnd, nCmdShow);
    UpdateWindow(g_hwnd);
    MSG msg;
    while (GetMessageW(&msg, NULL, 0, 0)) { TranslateMessage(&msg); DispatchMessageW(&msg); }
    return (int)msg.wParam;
}
